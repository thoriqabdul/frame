<footer class="footer text-center"> 2020 © Ample Admin brought to you by <a
    href="https://www.wrappixel.com/">wrappixel.com</a>
</footer>