@extends('admin.layouts.base')

@section('content')
    <h3>In Development</h3>
@endsection